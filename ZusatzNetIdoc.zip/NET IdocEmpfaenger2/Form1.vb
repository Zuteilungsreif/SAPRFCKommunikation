Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.ListBox3 = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(16, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(280, 48)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Start Listen"
        '
        'ListBox1
        '
        Me.ListBox1.Location = New System.Drawing.Point(16, 88)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(544, 108)
        Me.ListBox1.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 16)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Protkoll:"
        '
        'ListBox2
        '
        Me.ListBox2.Location = New System.Drawing.Point(16, 248)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(544, 43)
        Me.ListBox2.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 224)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Idoc-Kontrollsatz"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 304)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 16)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Idoc-Datens�tze"
        '
        'ListBox3
        '
        Me.ListBox3.Location = New System.Drawing.Point(16, 328)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(544, 160)
        Me.ListBox3.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(592, 501)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ListBox3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim WithEvents oIdocServer As IdocInboundServer

    Private Sub oIdocServer_Transaktion(ByVal Message As String) Handles oIdocServer.Transaktion
        ListBox1.Items.Add(Message)
    End Sub

    Private Sub oIdocServer_IdocEmpfang(ByVal KontrollSaetze As SAP.Connector.EDI_DC40_BLOCKList, _
        ByVal Datensaetze As SAP.Connector.EDI_DD40_BLOCKList) Handles oIdocServer.IdocEmpfang

        ' Jetzt werten wir das empfangene Idoc aus
        Dim c_tempSatz As SAP.Connector.EDI_DC40_BLOCK

        For Each c_tempSatz In KontrollSaetze
            ListBox2.Items.Add(c_tempSatz.Block)
        Next

        Dim d_tempSatz As SAP.Connector.EDI_DD40_BLOCK

        For Each d_tempSatz In Datensaetze
            ListBox3.Items.Add(d_tempSatz.Block)
        Next




    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        oIdocServer = New IdocInboundServer("-aKMS_TEST -gdb117de7.d-w.wuerth.com -xsapgw14")

        ListBox1.Items.Add("Server startet ...")

        Try
            oIdocServer.Start()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


End Class

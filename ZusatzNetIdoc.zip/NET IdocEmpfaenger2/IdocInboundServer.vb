Public Class IdocInboundServer : Inherits SAP.Connector.SAPServer

    ' Hier die beiden Events, um die aufrufende Klasse
    ' mit R�ckgabedaten zu versorgen
    Public Event Transaktion(ByVal Message As String)
    Public Event IdocEmpfang(ByVal KontrollSaetze As SAP.Connector.EDI_DC40_BLOCKList, _
        ByVal DatenSaetze As SAP.Connector.EDI_DD40_BLOCKList)


    ' Konstruktor -> wird einfach an die Basisklasse weitergeleitet
    Sub New(ByVal ConnectionString As String)
        MyBase.New(ConnectionString)
    End Sub

    ' Funtionsbaustein, der vom RFC-Framework aufgerufen wird
    <SAP.Connector.RfcMethod(AbapName:="IDOC_INBOUND_ASYNCHRONOUS", isTRfc:=True)> _
    Protected Sub IDOC_INBOUND_ASYNCHRONOUS( _
            <SAP.Connector.RfcParameter(AbapName:="IDOC_CONTROL_REC_40", _
            RfcType:=SAP.Connector.RFCTYPE.RFCTYPE_ITAB, _
            Direction:=SAP.Connector.RFCINOUT.INOUT, _
            Optional:=True, _
            STRUCTURE:="EDI_DC40")> _
            ByRef IDOC_CONTROL_REC_40 As SAP.Connector.EDI_DC40_BLOCKList, _
            <SAP.Connector.RfcParameter(AbapName:="IDOC_DATA_REC_40", _
            RfcType:=SAP.Connector.RFCTYPE.RFCTYPE_ITAB, _
            Direction:=SAP.Connector.RFCINOUT.INOUT, _
            Optional:=True, _
            STRUCTURE:="EDI_DD40")> _
            ByRef IDOC_DATA_REC_40 As SAP.Connector.EDI_DD40_BLOCKList)

        ' Wir machen gar nix mit den Daten, sondern
        ' geben Sie �ber ein Ereignis an die aufrufende Klasse
        ' zur�ck
        RaiseEvent IdocEmpfang(IDOC_CONTROL_REC_40, IDOC_DATA_REC_40)

    End Sub

    Protected Overrides Function CheckTransaction(ByVal tid As SAP.Connector.RfcTID) As Integer
        RaiseEvent Transaktion("CheckTransaction TID=" & tid.ToString)
        CheckTransaction = SAP.Connector.RFC_RC.RFC_OK
    End Function

    Protected Overrides Function CommitTransaction(ByVal tid As SAP.Connector.RfcTID) As Integer
        RaiseEvent Transaktion("CommitTransaction TID=" & tid.ToString)
        CommitTransaction = SAP.Connector.RFC_RC.RFC_OK
    End Function

    Protected Overrides Function ConfirmTransaction(ByVal tid As SAP.Connector.RfcTID) As Integer
        RaiseEvent Transaktion("ConfirmTransaction TID=" & tid.ToString)
        ConfirmTransaction = SAP.Connector.RFC_RC.RFC_OK
    End Function

    Protected Overrides Sub RollbackTransaction(ByVal tid As SAP.Connector.RfcTID)
        RaiseEvent Transaktion("RollbackTransaction TID=" & tid.ToString)
    End Sub
End Class

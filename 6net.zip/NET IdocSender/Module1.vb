Imports SAP.Connector.SAPIDocSender

Class App

    Shared Sub Main()

        Dim IdocNr As String
        IdocNr = "530747"

        Dim IdocSend As New SAP.Connector.SAPIDocSender( _
            "CLIENT=800 USER=Theobald PASSWD=pw " & _
            "LANG=DE ASHOST=schnecke SYSNR=10")
        Dim tid As New SAP.Connector.RfcTID(System.Guid.NewGuid)
        Dim oStream As New TheosStreamTools
        Dim string1 As String = Space(406)

        Console.WriteLine("tRFC-ID: " & tid.ToString)

        string1 = string1.Insert(0, "EDI_DC40")
        string1 = string1.Insert(10, "800") 'Mandant
        string1 = string1.Insert(35, "2") 'Richtung
        string1 = string1.Insert(39, "SYSTAT01") 'Basistyp
        string1 = string1.Insert(99, "STATUS") 'Nachrcihtentyp
        ' Absenderinfos
        string1 = string1.Insert(148, "A000000002") 'Absenderport
        string1 = string1.Insert(158, "LS") 'Partnerart
        string1 = string1.Insert(162, "SALES") 'Partnernummer
        ' Empf�ngerinfos
        string1 = string1.Insert(263, "SAPPT10017") 'Port
        string1 = string1.Insert(273, "LS") 'Partnerart
        string1 = string1.Insert(277, "B3TCLNT800") 'Partnernummer

        oStream.WriteToStream(string1 & vbCrLf)

        Dim string2 As String = Space(1063)

        ' Administrationsdaten der Segemnt-Zeile
        string2 = string2.Insert(0, "E1STATS") 'Segment
        string2 = string2.Insert(30, "800") 'Mandant
        string2 = string2.Insert(49, "000001") 'Segmentnummer
        string2 = string2.Insert(61, "01") 'Hierarchieebene

        ' Anwedungsdaten der Segemnt-Zeile
        string2 = string2.Insert(76, IdocNr) 'Idoc-Nummer
        string2 = string2.Insert(92, "20031010") 'Datum
        string2 = string2.Insert(100, "010101") 'Uhrzeit
        string2 = string2.Insert(106, "12") 'Idoc-Status
        string2 = string2.Insert(198, "Hallo welt !!")

        oStream.WriteToStream(string2 & vbCrLf)

        Console.WriteLine("versuche zu senden ....")

        Try
            IdocSend.SubmitIDoc(oStream.GetStreamReader, tid)
        Catch ex As Exception
            Console.WriteLine(ex.ToString)
        End Try

        Console.WriteLine("Versand abgeschlossen")
        Console.WriteLine("Der Status des Idocs " & IdocNr & _
            " wurde angepasst")

        Console.ReadLine()

    End Sub



End Class

Class TheosStreamTools

    Private p_stream As System.IO.MemoryStream


    Public Sub New()
        p_stream = New System.IO.MemoryStream
    End Sub

    Public Sub WriteToStream(ByVal TextToWrite As String)

        Dim TempChar1 As Char
        Dim Buffer(Len(TextToWrite) - 1) As Byte
        Dim x As Long

        For x = 0 To Len(TextToWrite) - 1
            Buffer(x) = Microsoft.VisualBasic.AscW( _
                TextToWrite.Substring(x, 1))
        Next

        p_stream.Write(Buffer, 0, Len(TextToWrite) - 1)

    End Sub

    Public Function GetStreamReader() As System.IO.StreamReader

        p_stream.Position = 0
        Return New System.IO.StreamReader(p_stream)

    End Function

    Public Function GetStreamWriter() As System.IO.StreamWriter
        Return New System.IO.StreamWriter(p_stream)
    End Function

    Overrides Function ToString() As String

        Dim Buffer(p_stream.Length - 1) As Byte
        p_stream.Position = 0
        Try
            p_stream.Read(Buffer, 0, p_stream.Length - 1)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim strBuffer As String
        Dim cBuffer(p_stream.Length - 1) As Char

        Dim x As Long
        For x = 0 To p_stream.Length - 1
            cBuffer(x) = Microsoft.VisualBasic.Chr(Buffer(x))
        Next x

        ToString = cBuffer
    End Function


End Class

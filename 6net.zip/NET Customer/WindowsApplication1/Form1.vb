Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(24, 24)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(168, 56)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Go!"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(232, 93)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Dest As New SAP.Connector.Destination
        Dest.Client = "800"
        Dest.AppServerHost = "Schnecke"
        Dest.SystemNumber = 10
        Dest.Username = "Theobald"
        Dest.Password = "pw"
        Dest.Language = "DE"


        Dim oProxy As New SAPProxyCustomer.SAPProxyCustomer(Dest.ConnectionString)
        Dim oKunde As New SAPProxyCustomer.BRFCKNA1Table

        oProxy.RFC_CUSTOMER_GET("0000001172", "", oKunde)

        Dim TID As SAP.Connector.RfcTID
        TID = SAP.Connector.RfcTID.NewTID()

        Dim qItem1 As New SAP.Connector.RfcQueueItem( _
            "TheosQueue", 2, TID)

        oKunde.Item(0).TELFX = "0711-74509-01"
        oProxy.QRfcRFC_CUSTOMER_UPDATE(oKunde, qItem1)

        Dim qItem2 As New SAP.Connector.RfcQueueItem( _
            "TheosQueue", 1, TID)

        oKunde.Item(0).TELFX = "0711-74509-02"
        oProxy.QRfcRFC_CUSTOMER_UPDATE(oKunde, qItem2)


        oProxy.Connection.Close()


    End Sub
End Class

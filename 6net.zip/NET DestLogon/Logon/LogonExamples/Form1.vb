Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.Button3 = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(288, 64)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "mit Destination-Klasse"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(16, 24)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(264, 24)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Logon"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Controls.Add(Me.ListBox1)
        Me.GroupBox2.Controls.Add(Me.Button3)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 80)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(288, 208)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "mit SAPLogonDestination-Klasse"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(16, 24)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(264, 24)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Destinationen auslesen"
        '
        'ListBox1
        '
        Me.ListBox1.Location = New System.Drawing.Point(16, 64)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(264, 95)
        Me.ListBox1.TabIndex = 3
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(16, 168)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(256, 24)
        Me.Button3.TabIndex = 1
        Me.Button3.Text = "Logon"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 301)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Conect-Example"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim oDest As New SAP.Connector.Destination

        oDest.AppServerHost = "Lovemachine"
        oDest.SystemNumber = "00"
        oDest.Username = "Theobald"
        oDest.Password = "pw"
        oDest.Client = "000"
        oDest.Language = "DE"

        Dim oCon As New SAP.Connector.SAPConnection(oDest)

        Try
            oCon.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return
        End Try

        MsgBox("Verbindung aufgebaut")
        oCon.Close()

    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim oDest As New SAP.Connector.SAPLogonDestination

        Dim enum1 As System.Collections.IEnumerator
        enum1 = oDest.AvailableDestinations.Values.GetEnumerator()

        Do While enum1.MoveNext
            ListBox1.Items.Add(enum1.Current)
        Loop
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim oDest As New SAP.Connector.SAPLogonDestination

        oDest.DestinationName = ListBox1.SelectedItem

        oDest.Username = "Theobald"
        oDest.Password = "pw"
        oDest.Client = "000"
        oDest.Language = "De"


        Dim oCon As New SAP.Connector.SAPConnection(oDest)

        Try
            oCon.Open()
        Catch exCom As SAP.Connector.RfcCommunicationException()
            MsgBox("Kommunikationsfehler:" & _
                vbCrLf & exCom.ToString)
        Catch exLog As SAP.Connector.RfcLogonException
            MsgBox("Anmeldefehler:" & _
                vbCrLf & exLog.ToString)
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return
        Finally
            oCon.Close()
        End Try

        MsgBox("Verbindung aufgebaut !!" & vbCrLf & _
            "SystemID: " & oCon.SystemID & vbCrLf & _
            "Realease: " & oCon.KernelRelease)

        oCon.Close()


    End Sub
End Class

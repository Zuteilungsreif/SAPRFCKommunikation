Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents TxtMat As System.Windows.Forms.TextBox
    Friend WithEvents TxtLief As System.Windows.Forms.TextBox
    Friend WithEvents TxtLagerort As System.Windows.Forms.TextBox
    Friend WithEvents TxtWerk As System.Windows.Forms.TextBox
    Friend WithEvents TxtMenge As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.TxtMat = New System.Windows.Forms.TextBox
        Me.TxtLief = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.TxtLagerort = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TxtWerk = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.TxtMenge = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Materialnummer"
        '
        'TxtMat
        '
        Me.TxtMat.Location = New System.Drawing.Point(96, 16)
        Me.TxtMat.Name = "TxtMat"
        Me.TxtMat.Size = New System.Drawing.Size(144, 20)
        Me.TxtMat.TabIndex = 1
        Me.TxtMat.Text = "B-7000"
        '
        'TxtLief
        '
        Me.TxtLief.Location = New System.Drawing.Point(96, 72)
        Me.TxtLief.Name = "TxtLief"
        Me.TxtLief.Size = New System.Drawing.Size(144, 20)
        Me.TxtLief.TabIndex = 3
        Me.TxtLief.Text = "0000001070"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Lieferant"
        '
        'TxtLagerort
        '
        Me.TxtLagerort.Location = New System.Drawing.Point(352, 40)
        Me.TxtLagerort.Name = "TxtLagerort"
        Me.TxtLagerort.Size = New System.Drawing.Size(144, 20)
        Me.TxtLagerort.TabIndex = 7
        Me.TxtLagerort.Text = "0001"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(264, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Lagerort"
        '
        'TxtWerk
        '
        Me.TxtWerk.Location = New System.Drawing.Point(352, 16)
        Me.TxtWerk.Name = "TxtWerk"
        Me.TxtWerk.Size = New System.Drawing.Size(144, 20)
        Me.TxtWerk.TabIndex = 5
        Me.TxtWerk.Text = "1000"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(264, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 16)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Werk"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(352, 72)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(144, 24)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Aktion ausf�hren"
        '
        'ListBox1
        '
        Me.ListBox1.Location = New System.Drawing.Point(8, 112)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(488, 173)
        Me.ListBox1.TabIndex = 9
        '
        'TxtMenge
        '
        Me.TxtMenge.Location = New System.Drawing.Point(96, 40)
        Me.TxtMenge.Name = "TxtMenge"
        Me.TxtMenge.Size = New System.Drawing.Size(144, 20)
        Me.TxtMenge.TabIndex = 11
        Me.TxtMenge.Text = "1000"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 40)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(88, 16)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Menge"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(624, 301)
        Me.Controls.Add(Me.TxtMenge)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TxtLagerort)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtWerk)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TxtLief)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtMat)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim x As Long
        Dim strDatum As String

        'strDatum = Year(Now) & VB.Right("00" & Month(Now), 2) & _
        '    VB.Right("00" & VB.Day(Now), 2)

        strDatum = "20021001"


        Dim Dest As New SAP.Connector.Destination
        Dest.Client = "800"
        Dest.AppServerHost = "Schnecke"
        Dest.SystemNumber = 10
        Dest.Username = "Theobald"
        Dest.Password = "pw"
        Dest.Language = "DE"

        Dim oProxy As New _
            SAPProxyPurchase.SAPProxyPurchase(Dest.ConnectionString)

        ListBox1.Items.Add("Verbindungsaufbau ...")

        Try
            oProxy.Connection.Open()
        Catch ex As Exception
            ListBox1.Items.Add("Fehler beim Verbinden !!")
            MsgBox(ex.ToString)
            Return
        End Try

        ListBox1.Items.Add("Verbindung aufgebaut")

        Dim BestellNummer As String
        Dim oAddress As SAPProxyPurchase.BAPIADDRESS
        Dim oHeader As New SAPProxyPurchase.BAPIEKKOC
        Dim oHeaderAddData As SAPProxyPurchase.BAPIEKKOA
        Dim oExtIn As SAPProxyPurchase.BAPIPAREXTable
        Dim oBusinessPartner As SAPProxyPurchase.BAPIEKKOPTable
        Dim oContractLimits As SAPProxyPurchase.BAPIESUCCTable
        Dim oItemAccountAssign As SAPProxyPurchase.BAPIEKKNTable
        Dim oItemAddData As SAPProxyPurchase.BAPIEKPOATable
        Dim oItemShedule As New SAPProxyPurchase.BAPIEKETTable
        Dim oItemShedule_Einzel As New SAPProxyPurchase.BAPIEKET
        Dim iTemText As SAPProxyPurchase.BAPIEKPOTXTable
        Dim oItems As New SAPProxyPurchase.BAPIEKPOCTable
        Dim oItems_Einzel As New SAPProxyPurchase.BAPIEKPOC
        Dim oLimits As SAPProxyPurchase.BAPIESUHCTable
        Dim oServices As SAPProxyPurchase.BAPIESLLCTable
        Dim oServiceTexts As SAPProxyPurchase.BAPIESLLTXTable
        Dim oAccassValues As SAPProxyPurchase.BAPIESKLCTable
        Dim oAddrDelivery As SAPProxyPurchase.BAPIMEPOADDRDELIVERYTable
        Dim oReturn As New SAPProxyPurchase.BAPIRETURNTable

        oHeader.DOC_TYPE = "NB"
        oHeader.PURCH_ORG = "1000"
        oHeader.PUR_GROUP = "010"
        oHeader.DOC_DATE = strDatum
        oHeader.VENDOR = TxtLief.Text

        oItems_Einzel.MATERIAL = TxtMat.Text
        oItems_Einzel.PUR_MAT = TxtMat.Text
        oItems_Einzel.STORE_LOC = TxtLagerort.Text
        oItems_Einzel.PLANT = TxtWerk.Text
        oItems_Einzel.PO_ITEM = "1"
        oItems.Add(oItems_Einzel)

        oItemShedule_Einzel.PO_ITEM = "1"
        oItemShedule_Einzel.DELIV_DATE = strDatum
        oItemShedule_Einzel.QUANTITY = TxtMenge.Text
        oItemShedule.Add(oItemShedule_Einzel)

        ListBox1.Items.Add("Bestellung wird erzeugt ....")

        oProxy.BAPI_PO_CREATE("", "", _
            oAddress, oHeader, oHeaderAddData, _
            "", BestellNummer, oExtIn, _
        oBusinessPartner, oContractLimits, _
        oItemAccountAssign, oItemAddData, _
        oItemShedule, iTemText, oItems, _
        oLimits, oServices, oServiceTexts, _
        oAccassValues, oAddrDelivery, oReturn)

        ListBox1.Items.Add("SAPReturn -> " & _
            oReturn.Item(0).MESSAGE())

        If BestellNummer = "" Then
            ListBox1.Items.Add("Aktion abgebrochen ...")
            Return
        End If

        Dim OGMCode As New SAPProxyPurchase.BAPI2017_GM_CODE
        Dim oGMHeader As New SAPProxyPurchase.BAPI2017_GM_HEAD_01
        Dim oGMHeadReturn As New SAPProxyPurchase.BAPI2017_GM_HEAD_RET
        Dim Belegnummer As String
        Dim oGMItems As New SAPProxyPurchase.BAPI2017_GM_ITEM_CREATETable
        Dim oGMItems_Einzel As New SAPProxyPurchase.BAPI2017_GM_ITEM_CREATE
        Dim oGMSerNum As New SAPProxyPurchase.BAPI2017_GM_SERIALNUMBERTable
        Dim oGMReturn As New SAPProxyPurchase.BAPIRET2Table

        ListBox1.Items.Add("Wareneingang wird gebucht ....")

        OGMCode.GM_CODE = "01"

        oGMHeader.DOC_DATE = strDatum
        oGMHeader.PSTNG_DATE = strDatum

        oGMItems_Einzel.PO_NUMBER = BestellNummer
        oGMItems_Einzel.PO_ITEM = "1"
        oGMItems_Einzel.MOVE_TYPE = "101"
        oGMItems_Einzel.MVT_IND = "B"
        oGMItems_Einzel.ENTRY_QNT = TxtMenge.Text
        oGMItems_Einzel.MOVE_REAS = "0000"
        oGMItems.Add(oGMItems_Einzel)

        Try
            oProxy.BAPI_GOODSMVT_CREATE(OGMCode, oGMHeader, "", _
                oGMHeadReturn, "2002", Belegnummer, oGMItems, _
                oGMSerNum, oGMReturn)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


        For x = 0 To oGMReturn.Count - 1
            ListBox1.Items.Add("SAPReturn -> " & _
                oGMReturn.Item(x).MESSAGE)
        Next

        If Trim(Belegnummer) <> "" Then
            ListBox1.Items.Add("Warenbewegung unter Nummer " & _
                Belegnummer & " erledigt")
            ListBox1.Items.Add("Vorgang komplett abgeschlossen, " & _
                "Commit wird durchgef�hrt")
            oProxy.CommitWork()
        Else
            ListBox1.Items.Add("Fehler!! Aktionen werden " & _
                "zur�ckgerollt.")
            oProxy.RollbackWork()
        End If

        oProxy.Connection.Close()

    End Sub
End Class

Public Class Form1
    Inherits System.Windows.Forms.Form

    Friend WithEvents IdocServ As SAP.Connector.SAPIDocReceiver
    Dim oStream As TheosStreamTools

    Private FileStream As System.IO.StreamWriter

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents cmdStart As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtMandant As System.Windows.Forms.TextBox
    Friend WithEvents txtIdocNr As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtBasisTyp As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdStart = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtMandant = New System.Windows.Forms.TextBox
        Me.txtIdocNr = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtBasisTyp = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.SuspendLayout()
        '
        'cmdStart
        '
        Me.cmdStart.Location = New System.Drawing.Point(8, 16)
        Me.cmdStart.Name = "cmdStart"
        Me.cmdStart.Size = New System.Drawing.Size(128, 24)
        Me.cmdStart.TabIndex = 0
        Me.cmdStart.Text = "Start Server"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(16, 304)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(128, 24)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Idoc aufbereiten"
        '
        'ListBox1
        '
        Me.ListBox1.Location = New System.Drawing.Point(8, 48)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(544, 108)
        Me.ListBox1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 168)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Mandant"
        '
        'txtMandant
        '
        Me.txtMandant.Location = New System.Drawing.Point(88, 168)
        Me.txtMandant.Name = "txtMandant"
        Me.txtMandant.Size = New System.Drawing.Size(48, 20)
        Me.txtMandant.TabIndex = 5
        Me.txtMandant.Text = ""
        '
        'txtIdocNr
        '
        Me.txtIdocNr.Location = New System.Drawing.Point(88, 192)
        Me.txtIdocNr.Name = "txtIdocNr"
        Me.txtIdocNr.Size = New System.Drawing.Size(120, 20)
        Me.txtIdocNr.TabIndex = 7
        Me.txtIdocNr.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 192)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "IdocNr"
        '
        'txtBasisTyp
        '
        Me.txtBasisTyp.Location = New System.Drawing.Point(304, 168)
        Me.txtBasisTyp.Name = "txtBasisTyp"
        Me.txtBasisTyp.Size = New System.Drawing.Size(80, 20)
        Me.txtBasisTyp.TabIndex = 9
        Me.txtBasisTyp.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(232, 168)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 16)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Basistyp"
        '
        'ListBox2
        '
        Me.ListBox2.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox2.ItemHeight = 14
        Me.ListBox2.Location = New System.Drawing.Point(16, 224)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(544, 74)
        Me.ListBox2.TabIndex = 10
        '
        'TreeView1
        '
        Me.TreeView1.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.Location = New System.Drawing.Point(16, 336)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.Size = New System.Drawing.Size(544, 328)
        Me.TreeView1.TabIndex = 11
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(568, 669)
        Me.Controls.Add(Me.TreeView1)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.txtBasisTyp)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtIdocNr)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtMandant)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.cmdStart)
        Me.Name = "Form1"
        Me.Text = "Idoc-Empf�nger"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStart.Click

        ListBox1.Items.Add("Starte Server ...")

        IdocServ = New SAP.Connector.SAPIDocReceiver("-atheo1 -gschnecke -xsapgw10")
        oStream = New TheosStreamTools

        Try
            IdocServ.Start()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim SegNode As TreeNode
        Dim Masternode As TreeNode
        Dim TempNode As TreeNode
        Dim strLine As String

        For Each strLine In ListBox2.Items
            If strLine.Substring(0, 8) = "EDI_DC40" Then
                ' wir haben den ersten Satz
                Masternode = New TreeNode(strLine)
                TreeView1.Nodes.Add(Masternode)
            Else
                SegNode = New TreeNode(strLine)
                SegNode.Tag = strLine.Substring(49, 6)

                If strLine.Substring(55, 6) <> "000000" Then
                    ' wir haben ein Subsegment gefunden
                    For Each TempNode In Masternode.Nodes
                        If TempNode.Tag = strLine.Substring(55, 6) Then
                            ' wir haben den passenden Elterknoten gefunden
                            ' und h�ngen dort das Segemnt ran
                            TempNode.Nodes.Add(SegNode)
                        End If
                    Next
                Else
                    Masternode.Nodes.Add(SegNode)
                End If
            End If
        Next




    End Sub

    Private Sub SapiDocReceiver1_Disposed(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub



    Private Sub IdocServ_BeginReceive( _
        ByVal sender As Object, _
        ByVal writeTo As SAP.Connector.SAPIDocReceiver.ReceiveEventArgs) _
        Handles IdocServ.BeginReceive

        ListBox1.Items.Add("Idocempfang beginnt")
        writeTo.WriteTo = oStream.GetStreamWriter

    End Sub

    Private Sub IdocServ_EndReceive( _
        ByVal sender As Object, ByVal writeTo As _
        SAP.Connector.SAPIDocReceiver.ReceiveEventArgs) _
        Handles IdocServ.EndReceive


        Dim strIdoc As String
        Dim strLine As String
        Dim strLines As String()

        Dim x As Long
        Dim sep(0) As Char

        strIdoc = oStream.ToString

        sep(0) = Chr(10)
        strLines = strIdoc.Split(sep)

        txtMandant.Text = Mid(strLines(0), 11, 3)
        txtBasisTyp.Text = Mid(strLines(0), 40, 30)
        txtIdocNr.Text = Mid(strLines(0), 14, 16)

        For Each strLine In strLines
            ListBox2.Items.Add(strLine)
        Next

        ListBox1.Items.Add("Idocempfang beendet")

    End Sub
End Class

Class TheosStreamTools

    Private p_stream As System.IO.MemoryStream


    Public Sub New()
        p_stream = New System.IO.MemoryStream
    End Sub

    Public Sub WriteToStream(ByVal TextToWrite As String)

        Dim TempChar1 As Char
        Dim Buffer(Len(TextToWrite) - 1) As Byte
        Dim x As Long

        For x = 0 To Len(TextToWrite) - 1
            Buffer(x) = Microsoft.VisualBasic.AscW( _
                TextToWrite.Substring(x, 1))
        Next

        p_stream.Write(Buffer, 0, Len(TextToWrite) - 1)

    End Sub

    Public Function GetStreamReader() As System.IO.StreamReader

        p_stream.Position = 0
        Return New System.IO.StreamReader(p_stream)

    End Function

    Public Function GetStreamWriter() As System.IO.StreamWriter
        Return New System.IO.StreamWriter(p_stream)
    End Function

    Overrides Function ToString() As String

        Dim Buffer(p_stream.Length - 1) As Byte
        p_stream.Position = 0
        Try
            p_stream.Read(Buffer, 0, p_stream.Length - 1)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim strBuffer As String
        Dim cBuffer(p_stream.Length - 1) As Char

        Dim x As Long
        For x = 0 To p_stream.Length - 1
            cBuffer(x) = Microsoft.VisualBasic.Chr(Buffer(x))
        Next x

        ToString = cBuffer
    End Function


End Class
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.AcceptsReturn = True
        Me.TextBox1.AcceptsTab = True
        Me.TextBox1.ImeMode = System.Windows.Forms.ImeMode.On
        Me.TextBox1.Location = New System.Drawing.Point(8, 8)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(440, 120)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "Report Z_TEMP_RFC." & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "WRITE sy-uline(40)." & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "WRITE: / 'SAP time:', 20 sy-uzeit." & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & _
        "WRITE: / 'User:', 20 sy-uname." & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "WRITE sy-uline (40)."
        '
        'TextBox2
        '
        Me.TextBox2.AcceptsReturn = True
        Me.TextBox2.AcceptsTab = True
        Me.TextBox2.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ImeMode = System.Windows.Forms.ImeMode.On
        Me.TextBox2.Location = New System.Drawing.Point(8, 160)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(440, 120)
        Me.TextBox2.TabIndex = 1
        Me.TextBox2.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 136)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(96, 16)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Go"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(112, 136)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(336, 16)
        Me.Label1.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 293)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click


        Dim Dest As New SAP.Connector.Destination

        Dest.Client = "000"
        Dest.AppServerHost = "lovemachine"
        Dest.SystemNumber = 0
        Dest.Username = "Theobald"
        Dest.Password = "pinhead5"
        Dest.Language = "DE"

        Dim oABAPRep As New SAPProxyRFCInstall.SAPProxyRFCInstall

        oABAPRep.Connection = _
            New SAP.Connector.SAPConnection(Dest.ConnectionString)

        Try
            oABAPRep.Connection.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return
        End Try

        Dim x As Long

        Dim oABAPProg As New SAPProxyRFCInstall.PROGTABTable
        Dim ProgZeile As SAPProxyRFCInstall.PROGTAB

        For x = 0 To TextBox1.Lines.GetUpperBound(0)
            ProgZeile = New SAPProxyRFCInstall.PROGTAB
            ProgZeile.Line() = TextBox1.Lines(x)
            oABAPProg.Add(ProgZeile)
        Next x

        Dim oABAPWrite As New SAPProxyRFCInstall.LISTZEILETable
        Dim ErrorMsg As String

        Try
            oABAPRep.Rfc_Abap_Install_And_Run("F", _
                "<<RFC>>", ErrorMsg, oABAPProg, oABAPWrite)
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return
        End Try

        If Len(ErrorMsg) Then
            MsgBox("Fehler im Programm: " & _
                ErrorMsg.ToString)
            Return
        End If

        For x = 0 To oABAPWrite.Count - 1
            TextBox2.Text = TextBox2.Text & _
                vbCrLf & oABAPWrite.Item(x).Zeile()
        Next

    End Sub

End Class
